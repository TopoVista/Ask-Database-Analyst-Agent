---
name: historical-metric-debugger
description: Reconstruct a business metric from four immutable inputs and return deterministic data, definition, interaction, and Shapley attribution. Use for metric regressions, restatements, and historical result disputes.
version: 0.1.0
tags: [metrics, debugging, reproducibility, finance]
---
# Historical Metric Debugger

Use this skill only when exact A/B/C/D historical metric values or a
MetricTrace replay endpoint are available. Do not infer missing evidence.

## Modes

- Local: `python -m metrictrace_sdk.cli attribute --a ... --b ... --c ... --d ...`
- Remote: use the authenticated MetricTrace replay API through the SDK/CLI.

## Workflow

1. Confirm workspace authorization for remote IDs.
2. Collect A=old data/old definition, B=old/new, C=new/old, D=new/new.
3. Run the deterministic CLI; never recompute attribution in prompt text.
4. Report the exact cells, three-part reconciliation, and Shapley allocations.
5. If a cell failed or evidence is unavailable, stop and identify that state.

## Security

Never print tokens, connection strings, raw rows, or manifests outside the
authorized workspace. State-changing remote calls require user authorization.
