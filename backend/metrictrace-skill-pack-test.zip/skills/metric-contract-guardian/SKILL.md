---
name: metric-contract-guardian
description: Evaluate deterministic metric-contract evidence when contracts are available; otherwise report that the capability is unavailable.
version: 0.1.0
---
# Metric Contract Guardian

Do not simulate or fabricate contract outcomes. When the MetricTrace contract
API is unavailable, explain the missing prerequisite and recommend a replay or
definition review instead.
