---
name: decision-evidence-verifier
description: Verify whether a decision has complete MetricTrace evidence, including exact versions, definitions, results and replay status.
version: 0.1.0
---
# Decision Evidence Verifier

Require immutable source versions, metric definition IDs, execution status and
the relevant replay/observation before accepting a claim. Do not assert that a
legacy chat transcript or current database state reproduces a past decision.
