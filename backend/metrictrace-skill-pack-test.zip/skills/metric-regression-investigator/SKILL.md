---
name: metric-regression-investigator
description: Investigate a reproduced business-metric change using exact replay cells and evidence-grounded attribution.
version: 0.1.0
---
# Metric Regression Investigator

Begin with a completed MetricTrace replay. Separate data, definition and
interaction changes. Cite immutable input IDs and abstain when any required
cell is unavailable. This skill does not execute source mutations.
