---
name: metric-definition-reviewer
description: Compare two immutable metric definitions for replay compatibility and semantic risk.
version: 0.1.0
---
# Metric Definition Reviewer

Compare canonical SQL, parameter contracts, unit, currency and source schema.
Use a historical replay when versions are available. Treat a schema mismatch or
non-scalar result as a blocking review result, not a suggested workaround.
