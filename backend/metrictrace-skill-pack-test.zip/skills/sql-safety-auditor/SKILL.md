---
name: sql-safety-auditor
description: Review metric SQL for read-only execution and historical replay safety. Use before saving or executing a metric definition.
version: 0.1.0
---
# SQL Safety Auditor

Use MetricTrace SQL validation as the authority. Reject writes, multiple
statements, untrusted table functions and queries that do not yield one
non-null scalar metric result. Report unsupported operations; do not repair by
silently changing metric meaning.
